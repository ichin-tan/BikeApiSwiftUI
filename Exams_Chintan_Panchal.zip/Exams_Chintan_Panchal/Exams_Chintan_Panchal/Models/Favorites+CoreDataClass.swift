//
//  Favorites+CoreDataClass.swift
//  Exams_Chintan_Panchal
//
//  Created by CP on 12/03/25.
//
//

import Foundation
import CoreData

@objc(Favorites)
public class Favorites: NSManagedObject {

}
