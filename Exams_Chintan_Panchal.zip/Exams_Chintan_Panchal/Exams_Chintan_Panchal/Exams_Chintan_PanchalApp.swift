//
//  Exams_Chintan_PanchalApp.swift
//  Exams_Chintan_Panchal
//
//  Created by CP on 12/03/25.
//

import SwiftUI

@main
struct Exams_Chintan_PanchalApp: App {    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
